from django.contrib import admin
from .models import OurDB

admin.site.register(OurDB)

# Register your models here.

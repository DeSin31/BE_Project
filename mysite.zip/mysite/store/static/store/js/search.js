/* 

Dribbble Rebound of Liang Shi's original shot
http://dribbble.com/shots/843289-Search-Bar?list=tags&tag=ui

Follow Me on Twitter: https://twitter.com/cameronbaney

*/
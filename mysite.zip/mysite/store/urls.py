from django.conf.urls import url
from django.conf import settings
from django.conf.urls.static import static
from . import views
urlpatterns = [
    url(r'^$', views.index, name='Index'),
    url(r'^mydatabase$', views.post_list, name='Post_list'),
    url(r'^upload$', views.uploadFile, name='Upload'),
    url(r'^uploadFile$', views.upload, name='UploadFile'),
    url(r'^search$', views.search, name='Search'),
    url(r'^searchFile$', views.search_results, name='SearchFile')
]

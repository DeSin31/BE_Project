from django.shortcuts import render
from django.db.models import Q
from .models import OurDB
import rake

# Create your views here.
def post_list(request):
    posts= OurDB.objects.order_by('title')
    return render(request, 'store/post_list.html', {'posts': posts})

def  index(request):
    return render(request, 'store/index.html')

def uploadFile(request):
    return render(request, 'store/upload.html')

def search(request):
    return render(request, 'store/search.html')

def search_results(request):
    postSearch = request.POST.get('term')
    search_list = postSearch.split(' ')
    papers = OurDB.objects.all()

    q = Q(key1__icontains=search_list[0]) | Q(key2__icontains=search_list[0]) | Q(key3__icontains=search_list[0]) | Q(key3__icontains=search_list[0]) | Q(key5__icontains=search_list[0]) | Q(key6__icontains=search_list[0]) | Q(key7__icontains=search_list[0])
    for term in search_list[1:]:
        q.add(Q(key1__icontains=term) | Q(key2__icontains=term) | Q(key3__icontains=term) | Q(key3__icontains=term) | Q(key5__icontains=term) | Q(key6__icontains=term) | Q(key7__icontains=term), q.connector)

    papers = papers.filter(q)
    return render(request,'store/results.html', {'papers': papers })

def upload(request):
    postTitle = request.POST.get('title')
    postFile = request.FILES['file']
    data = OurDB(
        title = postTitle,
        document = postFile  
        )
    data.save()
    test = str(OurDB.objects.get(title=postTitle).document)
    test = "C:\\Users\\Devika\\Anaconda3\\Lib\\site-packages\\mysite\\" + test
    keywords =rake.doRake(test)
    data.key1=keywords[0]
    data.key2=keywords[1]
    data.key3=keywords[2]
    data.key4=keywords[3]
    data.key5=keywords[4]
    data.key6=keywords[5]
    data.key7=keywords[6]
    data.save()
    return render(request,'store/success.html')

